module.exports=[19346,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_page_actions_8bab4192.js.map