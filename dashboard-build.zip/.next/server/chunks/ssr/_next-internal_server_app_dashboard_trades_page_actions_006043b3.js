module.exports=[12613,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_trades_page_actions_006043b3.js.map